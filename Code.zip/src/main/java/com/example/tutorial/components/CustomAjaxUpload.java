/**
 * 
 */
package com.example.tutorial.components;

import org.got5.tapestry5.jquery.components.AjaxUpload;

/**
 * @author dusanstanojevic
 *
 */
public class CustomAjaxUpload extends AjaxUpload {

}