/**
 * 
 */
package com.example.tutorial.components;

import com.example.tutorial.annotations.AnonymousAccess;

/**
 * @author dusanstanojevic
 *
 */
@AnonymousAccess
public class ExceptionReport {

}