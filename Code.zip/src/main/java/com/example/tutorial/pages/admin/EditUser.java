/**
 * 
 */
package com.example.tutorial.pages.admin;

/**
 * @author dusanstanojevic
 *
 */
public class EditUser {

}