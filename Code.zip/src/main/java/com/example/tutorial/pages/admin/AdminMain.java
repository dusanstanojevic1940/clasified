/**
 * 
 */
package com.example.tutorial.pages.admin;

import com.example.tutorial.annotations.AdminPage;

/**
 * @author dusanstanojevic
 *
 */
@AdminPage
public class AdminMain {

}