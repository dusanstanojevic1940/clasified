/**
 * 
 */
package com.example.tutorial.pages.error;

import com.example.tutorial.annotations.AnonymousAccess;

/**
 * @author dusanstanojevic
 *
 */
@AnonymousAccess
public class Missing500 {

}