/**
 * 
 */
package com.example.tutorial.pages.view;

/**
 * @author dusanstanojevic
 *
 */
public class IPN {

}