/**
 * 
 */
package com.example.tutorial.pages.pp;

/**
 * @author dusanstanojevic
 *
 */
public class ResponseCancel {

}