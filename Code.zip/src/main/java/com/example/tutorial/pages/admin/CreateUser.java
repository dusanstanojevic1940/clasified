/**
 * 
 */
package com.example.tutorial.pages.admin;

import org.apache.tapestry5.annotations.Property;

import com.example.tutorial.entities.User;

/**
 * @author dusanstanojevic
 *
 */
public class CreateUser {
	@Property
	private User user;
}