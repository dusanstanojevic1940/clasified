/**
 * 
 */
package com.example.tutorial.pages.admin.edit;

import com.example.tutorial.annotations.AdminPage;

/**
 * @author dusanstanojevic
 *
 */
@AdminPage
public class SellingItem {

}